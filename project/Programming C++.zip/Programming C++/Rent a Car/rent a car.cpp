//PROGRAM FILENAME	    :	TMC1434 DATA STRUCTURE AND ALGORITHM
// LECTURER		    :   EaqerZilla Phang

//Saber Al Tarek           : 64544 (Matric. No)


// This program is created and tested by code::blocks 16.01

#include <iostream>
#include <stdlib.h>
#include <string>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iomanip>


#define max 10

using namespace std;
//the header file

class Function//base class
{
public:

    void add_customer();//to add a new customer
	void display_customer(); //to display the customer list
	void search_car(); // to search car
	void modify_customer();//to modify customer details
	void search_customer();//to search customer and the car rented
	void delete_customer();  //to delete a customer from customer list
	void rent_car();
	void delete_customer(int num); //overloading
	void exit(); //function to exit system
    Function();//constuctor

};

Function::Function()
{

}




struct node //constract node
{
	int Customer_Id;
    string Name,Telephone_No,Email,Address,Nationality,Licence,Time;
    string Date,Due_Date,Car_Type,status,Vendor,Model,Capacity,Mileagerange;
    int Car_Rent, mileage,Total;
    int Reciept_No;
    node *next;
	node *link;

};
node *start_ptr = NULL;
node *head = NULL;


int main()// Main function
{

	system("COLOR F9");
    Function customer;
	int menu;

do
	{
		system("cls");
		cout<<"\t\tWelcome to the Kenyalang Car Rental Centre System\n";
		cout<<"\t\t--------------------------------------------------\n\n\n\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t1. Add New Customer \t\t\t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t2. Pay & Rent a Car \t\t\t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t3. Delete Customer \t\t\t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t4. Modify Customer details \t\t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t5. Search Car Status and Due  \t\t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t6. Search for Rental Information  \t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t7. Display Customer List \t\t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"\t\t|\t8. Exit\t\t\t\t\t |\n";
		cout<<"\t\t--------------------------------------------------\n";
		cout<<"Enter choice: ";

		cin>>menu;

		switch (menu)
		{
		case 1:
			{
				customer.add_customer();// function add
				system("PAUSE");
				break;
			}//end case 1


        case 2:
			{
				customer.rent_car();//funtion rent_car
				system("PAUSE");
				break;
			}//end case 2


        case 3:
			{
				customer.delete_customer();//funtion delete
				system("PAUSE");
				break;
			}//end case 2
		case 4:
			{
				customer.modify_customer();//function modify
				system("PAUSE");
				break;
			}//end case 4

        case 5:
			{
				customer.search_car();//function search car
				system("PAUSE");
				break;
			}//end case 4

        case 6:
			{
				customer.search_customer();//function to search car
				system("PAUSE");
				break;
			}//end case 4



         case 7:
			{
				customer.display_customer();//function display
				system("PAUSE");
				break;
			}//end case 4


		 case 8:
			{
				customer.exit();//function exit
				goto a;
				break;
			}//end case 5
		default:
			{
				cout<<"You enter invalid input\nre-enter the input\n"<<endl;
				break;
			}//end defeault
		}//end if
	}while(menu!=9);//end do
 a:// goto
	cout<<"thank you"<<endl;

	system ("PAUSE");
	return 0;
}//end int main



void  Function::add_customer()//function to add new customer
{
	system("cls");

    node *temp;
	temp=new node;
    cout <<"\t***********************************************************\n";
    cout <<"\t\t\t Kenyalang Car Rent System\n";
	cout <<"\t***********************************************************\n\n";
    cout <<"\t\tAdd Customer details \n\n";
    cout <<"\n_______________________________________________________________________\n\n";
    cout <<"\t\tCustomer Id : ";
	cin >>temp->Customer_Id;
	cout << "\n";
	cout <<"\t\tCustomer Name : ";
    cin >>temp->Name;
    cout << "\n";
    cout <<"\t\tCustomer Address : ";
    cin >>temp->Address;
	cout << "\n";
    cout <<"\t\tCustomer Telephone No : ";
    cin >>temp->Telephone_No;
    cout << "\n";
    cout <<"\t\tCustomer Email : ";
    cin >>temp->Email;
    cout << "\n";
    cout <<"\t\tCustomer Nationality : ";
    cin >>temp->Nationality;
    cout << "\n";
    cout <<"\t\tRented Time : ";
    cin >>temp->Time;
    cout << "\n";
    cout <<"\t\tMalaysian Driving licence : ";
    cin >>temp->Licence;
    cout <<"\n_______________________________________________________________________\n\n";

    temp->next=NULL;

    if(start_ptr!=NULL)
		       {
					temp->next=start_ptr;
				}
		 start_ptr=temp;

} //close function void add Customer

void Function::rent_car()//function rent_car
{
	system("cls");
	node *temp;
	temp=start_ptr;
	Function customer;
	int Customer_Id;
	int Car_Rent,days,TvCharge,nationality;
	float Total, mileage, discount,insurance;

	cout <<"\t***********************************************************\n";
    cout <<"\t\t\t Kenyalang Car Rent System\n";
    cout <<"\t***********************************************************\n\n";

    cout <<"\t----------------------------------------------------------\n";
    cout <<"\t\t\t 1.Malaysian(local)\n";
    cout <<"\t----------------------------------------------------------\n\n";
    cout <<"\t----------------------------------------------------------\n";
    cout <<"\t\t\t 2.Foreigner\n";
    cout <<"\t----------------------------------------------------------\n";

    cin >>nationality;

    switch (nationality)
		{

		case 1:
			{
				if(temp == NULL){
                int i;

                cout << "\t\tThere is no Customer in the list\n\n\t\tTo give a Car for rent enlist the customer first\n\t\tTo do that Press 1 ...... \n";
                cin >> i ;

                if(i==1){

                customer.add_customer();// function add

				}else{cout << "Invalid Customer Id\n";}


                }else{
                    cout<<"\t\tEnter The Customer Id: ";
                    cin>>Customer_Id;
                    while(temp!=NULL){
                    if(Customer_Id==temp->Customer_Id)
                    {
			    cout <<"\t\tCustomer Id : " << temp->Customer_Id << endl;
                cout <<"\t\tCustomer Name : " << temp->Name << endl;;
                cout <<"\t\tCustomer Address : " << temp->Address << endl;
                cout <<"\t\tCustomer Telephone No : " << temp->Telephone_No <<endl;
                cout <<"\t\tCustomer Email : " << temp->Email << endl;
                cout <<"\t\tCustomer Nationality : " << temp->Nationality<< endl;
                cout <<"\t\tRented Time : " << temp->Time<< endl;
                cout << "\n\n";
                cout <<"\t\tDate : " << temp->Date;
                cin >> temp->Date;
                cout << "\n";
                cout << "\t\tDue Date : " ;
                cin >> temp->Due_Date;
                cout <<"\n\n\t_________________________________________________________________\n";
                cout <<"\t\tDetails of Car you want to Rent \n";
                cout <<"\t_________________________________________________________________\n\n";

                cout<<"\t---------------------------------------------------------------------\n";
				cout<< " \t\tMicrocar (Group A) : RM 100\n\t\tSaloon (Group B): RM150\n\t\t Multipurpose (Group C): RM 200\n\t\tMotorcycle (Group D): RM20\n" ;
                cout<<"\t---------------------------------------------------------------------\n";

                cout <<"\t\tReciept No: ";
                cin>>temp->Reciept_No;
			    cout << "\n\n";
			    cout <<"\t\tWhat Type of car You Want to Rent : ";
                cin>>temp->Car_Type;
                cout << "\n\n";
			    cout << "\t\tCar Vendor : ";
			    cin>>temp->Vendor;
                cout << "\n\n";
                cout << "\t\tCar Model : ";
			    cin>>temp->Model;
			    cout<<"\n\n";
                cout <<"\t\tCar Engine Capacity : ";
				cin>>temp->Capacity;
				cout << "\n\n";
                cout << "\t\tRent of Your Car Perday : ";
			    cin>>Car_Rent;
			    cout << "\n\n";
			    cout << "\t\tAdditional feature rent (TV): ";
                cin>>TvCharge;
                cout<<"\n\n";
			    cout << "\t\tFor How Many Days : ";
			    cin >> days;
			    cout << "\n\n";
			    cout << "\t\tMileage Range : ";
			    cin >> temp->mileage;
			    cout << "\n\n";
			    cout << "\t\tDiscount Percent (0.10 off if rented more than 3 Times) : ";
			    cin >> discount;
			    cout << "\n\n";

			    if (mileage>300){
			    Total = (Car_Rent + TvCharge)*days + ((Car_Rent + TvCharge)*days)*0.50 - (Car_Rent + TvCharge)*days*discount ;

			    cout << "You have to pay total : " << Total<< endl;
			    cout << "\n\n";
			    }else{
			        Total = (Car_Rent + TvCharge)*days + ((Car_Rent + TvCharge)*days)*0.20 - (Car_Rent + TvCharge)*days*discount ;
                    cout << "\t\tYou have to pay total : " << Total<< endl;
                    cout << "\n\n";
			    };

			    cout << "\t\tPaid Amount: ";
			    cin >> temp->Total;
			    cout << "\n\n";
			    cout << "\t\tStatus : ";
			    cin >> temp->status;
                cout <<"\n\t___________________________________________________________________\n\n";

              system("PAUSE");
              break;

			}else
                {temp=temp->next;
			    }
		}
	}
             break;

			}//end case 1


        case 2:
			{
				if(temp == NULL) //Invalid Customer Id
	{
	    int i;

        cout << "\t\tThere is no Customer in the list\n\n\t\tTo give a Car for rent enlist the customer first\n\t\tTo do that Press 1 ...... \n";
		cin >> i ;

		if(i==1){

                customer.add_customer();// function add

				}else{cout << "Invalid Customer Id\n";}


	}
	else{
		cout<<"\t\tEnter The Customer Id: ";
		cin>>Customer_Id;
		while(temp!=NULL)
            {
			if(Customer_Id==temp->Customer_Id)
			{
			    cout <<"\t\tCustomer Id : " << temp->Customer_Id << endl;
                cout <<"\t\tCustomer Name : " << temp->Name << endl;;
                cout <<"\t\tCustomer Address : " << temp->Address << endl;
                cout <<"\t\tCustomer Telephone No : " << temp->Telephone_No <<endl;
                cout <<"\t\tCustomer Email : " << temp->Email << endl;
                cout <<"\t\tCustomer Nationality : " << temp->Nationality<< endl;
                cout <<"\t\tRented Time : " << temp->Time<< endl;
                cout << "\n\n";
                cout <<"\t\tDate : " << temp->Date;
                cin >> temp->Date;
                cout << "\n";
                cout << "\t\tDue Date : " ;
                cin >> temp->Due_Date;
                cout <<"\n\n\t_________________________________________________________________\n";
                cout <<"\t\tDetails of Car you want to Rent \n";
                cout <<"\t_________________________________________________________________\n\n";

                cout<<"\t---------------------------------------------------------------------\n";
				cout<< " \t\tMicrocar (Group A) : RM 100\tSaloon (Group B): RM150\n\t\t Multipurpose (Group C): RM 200\tMotorcycle (Group D): RM20\n" ;
                cout<<"\t---------------------------------------------------------------------\n";

                cout <<"\t\tReciept No: ";
                cin>>temp->Reciept_No;
			    cout << "\n\n";
			    cout <<"\t\tWhat Type of car You Want to Rent : ";
                cin>>temp->Car_Type;
                cout << "\n\n";
			    cout << "\t\tCar Vendor : ";
			    cin>>temp->Vendor;
                cout << "\n\n";
                cout << "\t\tCar Model : ";
			    cin>>temp->Model;
			    cout<<"\n\n";
                cout <<"\t\tCar Engine Capacity : ";
				cin>>temp->Capacity;
				cout << "\n\n";
                cout << "\t\tRent of Your Car Perday : ";
			    cin>>Car_Rent;
			    cout << "\n\n";
			    cout << "\t\tAdditional feature rent (TV): ";
                cin>>TvCharge;
                cout<<"\n\n";
			    cout << "\t\tFor How Many Days : ";
			    cin >> days;
			    cout << "\n\n";
			    cout << "\t\tMileage : ";
			    cin >> temp->mileage ;
			    cout << "\n\n";
			    cout << "\t\tInsurance Charge(Saloon=100 Multipurpose=300) : ";
			    cin >> insurance;
			    cout << "\n\n";
                if (mileage>300){
			    Total = (Car_Rent + TvCharge)*days + ((Car_Rent + TvCharge)*days)*0.5+ mileage + insurance;

			    cout << "\t\tYou have to pay total : " << Total<< endl;

			    }else{
			        Total = (Car_Rent + TvCharge)*days + (Car_Rent + TvCharge)*0.2 + mileage  + insurance;
			        cout << "\t\tYou have to pay total : " << Total<< endl;

			    };

                cout << "\n\n";
			    cout << "\t\tPaid Amount: ";
			    cin >> temp->Total;
			    cout << "\n\n";
			    cout << "\t\tStatus : ";
			    cin >> temp->status;
                cout <<"\n\t___________________________________________________________________\n\n";

                system("PAUSE");
				break;

			}else
			{
				temp=temp->next;
			}
		}
	}

				break;
			}//end case 2


}//end of function rent_car()
}

void Function::delete_customer()//function to delete receipt
{
    system("cls");
	node *del = NULL;
	node *temp,*temp1;
	temp = start_ptr;
	temp1 = start_ptr;

	int Customer_Id;

	cout <<"\t***********************************************************\n";
    cout <<"\t\t\t Kenyalang Car Rent System\n";
    cout <<"\t***********************************************************\n\n\n";

	cout<<"\nEnter the customer number to be deleted?\t";
	cin >> Customer_Id;

	while(temp1 != NULL && temp1->Customer_Id !=Customer_Id)
	{
		temp = temp1;
		temp1 = temp1->next;
	}//End while loop

	if(temp1 == NULL)

	{
		cout <<"Sorry, Customer No. "<< Customer_Id << "  was not in the list" << endl;
		delete del;
	}//End if

	else if(Customer_Id == temp->Customer_Id)

	{
		node *last = NULL;
		start_ptr=start_ptr->next;

		if ( last == temp1)
		{
			last = last->next;
			delete temp;
		}

	}//End else if

	else
	{
		del = temp1;
		temp1 = temp1->next;
		temp->next = temp1;
		delete del;
	}//End else
	cout<<"\nThe Customer is deleted."<<endl;
	system("cls");

}//end function delete_customer()


void Function::delete_customer(int num)
{

}

void Function::modify_customer()//function to modify_customer
{
	system("cls");
	node *temp;
	int Customer_Id;
	temp=start_ptr;

	if(temp == NULL) //Invalid Customer Id
	{
	}
	else
	{
		cout<<"Enter The Customer Id: ";
		cin>>Customer_Id;
		while(temp!=NULL)
		{
			if(Customer_Id==temp->Customer_Id)
			{
				cout <<"\t***********************************************************\n";
				cout <<"\t\t\t Kenyalang Car Rent System\n";
				cout <<"\t***********************************************************\n\n";

				cout <<"\t\tModify the Customer details \n\n";
				cout <<"\t-----------------------------------------------------------\n\n";
				cout <<"\t\tCustomer No : "<<temp->Customer_Id << endl;
				cout <<"\t\tCustomer Name : " << temp->Name << endl;
				cout <<"\t\tCustomer Nationality : " << temp->Nationality <<endl;
				cout <<"\t-----------------------------------------------------------\n\n";
				cout <<"\t\tCustomer Previous Address : " << temp->Address << endl;
				cout <<"\t\tCustomer New Address : " ;
                cin >>temp->Address;
                cout << "\n";
                cout <<"\t\tCustomer Previous Telephone No : " << temp->Telephone_No << endl;
                cout <<"\t\tCustomer New Telephone No : ";
                cin >>temp->Telephone_No;
                cout << "\n";
                cout <<"\t\tCustomer Previous Email : " << temp->Email << endl;
                cout <<"\t\tCustomer New Email : ";
                cin >>temp->Email;
                cout << "\n";
                cout <<"\t\tPrevious Rented Times : " << temp->Time<< endl;
                cout <<"\t\tRented Times : ";
                cin >>temp->Time;
                cout <<"\n_______________________________________________________________________\n";

				temp=temp->next;
			}

			else
			{
				temp=temp->next;
			}

		}
	}
}//end Modify customer Details Function

void Function::search_car()//function to Search Car
{
	system("cls");
	node *temp;
	int Reciept_No;
	temp=start_ptr;

	if(temp == NULL) //Invalid Customer Id
	{
	    cout <<"\t***********************************************************\n";
        cout <<"\t\t\t Kenyalang Car Rent System\n";
        cout <<"\t***********************************************************\n\n";

		cout << "There is no Car enlisted\n\t\tOR\n\n\tInvalid Customer Id\n";
	}
	else
	{
		cout<<"\t\tEnter The Receipt No : ";
		cin>>Reciept_No;
		while(temp!=NULL)
		{
			if(Reciept_No==temp->Reciept_No)
			{
				cout <<"\t***********************************************************\n";
				cout <<"\t\t\t Kenyalang Car Rent System\n";
				cout <<"\t***********************************************************\n\n";

				cout <<"\t\t Car details and status\n\n";
                cout <<"\t\tReciept No: " << temp->Reciept_No << endl;
        	    cout << "\t\tDue Date: " << temp->Due_Date << endl;
			    cout <<"\t\tType of car Rented : " << temp->Car_Type <<endl;
        	    cout << "\t\tCar Vendor : " << temp->Vendor <<endl;
			    cout << "\t\tCar Model : " << temp->Model<<endl;
			    cout << "\t\tTotal Amount to Pay : " << temp->Total <<endl;
			    cout << "\t\tPayment Status " << temp->status <<endl;

				cout <<"\t-----------------------------------------------------------\n\n";
				cout <<"\t\tCustomer ID : "<<temp->Customer_Id << endl;
				cout <<"\t\tCustomer Name : " << temp->Name << endl;
				cout <<"\t\tCustomer Telephone No : " << temp->Telephone_No << endl;
                cout <<"\t\tCustomer Email : " << temp->Email << endl;
                cout <<"\n_______________________________________________________________________\n\n";



				temp=temp->next;
			}

			else
			{
				temp=temp->next;
			}
		}
	}
} // end of function search car

void Function::search_customer()//function to search_customer
{
	system("cls");
	node *temp;
	int Customer_Id;
	temp=start_ptr;

	if(temp == NULL) //Invalid Customer Id
	{
	    cout <<"\t***********************************************************\n";
        cout <<"\t\t\t Kenyalang Car Rent System\n";
        cout <<"\t***********************************************************\n\n";

		cout << "There is no Customer enlisted\n\t\tOR\n\n\tInvalid Customer Id\n";
	}
	else
	{
		cout<<"\t\tEnter The Customer Id: ";
		cin>>Customer_Id;
		while(temp!=NULL)
		{
			if(Customer_Id==temp->Customer_Id)
			{
				cout <<"\t***********************************************************\n";
				cout <<"\t\t\t Kenyalang Car Rent System\n";
				cout <<"\t***********************************************************\n\n";

				cout <<"\t\t Customer details \n\n";
				cout <<"\t-----------------------------------------------------------\n\n";
				cout <<"\t\tCustomer ID : "<<temp->Customer_Id << endl;
				cout <<"\t\tCustomer Name : " << temp->Name << endl;
				cout <<"\t\tCustomer Nationality : " << temp->Nationality << endl;
				cout <<"\t\tCustomer Address : " << temp->Address << endl;
				cout <<"\t\tCustomer Telephone No : " << temp->Telephone_No << endl;
                cout <<"\t\tCustomer Email : " << temp->Email << endl;
                cout <<"\t\tRented Times : "<< temp->Time;
                cout <<"\n_______________________________________________________________________\n\n";

                cout <<"\t\tReciept No: " << temp->Reciept_No << endl;
        	    cout << "\t\tDue Date: " << temp->Due_Date << endl;
			    cout <<"\t\tType of car You Rented : " << temp->Car_Type <<endl;
        	    cout << "\t\tCar Vendor : " << temp->Vendor <<endl;
			    cout << "\t\tCar Model : " << temp->Model<<endl;
			    cout << "\t\tTotal Amount To Pay : " << temp->Total <<endl;

				temp=temp->next;
			}

			else
			{
				temp=temp->next;
			}
		}
	}
} // end function search customer



void Function::display_customer()//Function to display Customer list
{
	system("cls");
	node *temp ;

	temp=start_ptr;


	if(temp == NULL) // empty list
	{
		cout << "\t\t\tThere is no Car Listed yet\n\t\t\tSo The List is Empty\n\n\n";
	}
	else
	{
		cout <<"\t\t\t\t Kenyalang Car rent System\n";
		cout <<"\t***********************************************************\n";
		cout <<"Here is the Customer Details: \n\n";
        cout <<"\n_______________________________________________________________________\n\n";

		while(temp!=NULL)
		{
				cout <<"\t\tCustomer Id : " << temp->Customer_Id << endl;
                cout <<"\t\tCustomer Name : " << temp->Name << endl;;
                cout <<"\t\tCustomer Address : " << temp->Address << endl;
                cout <<"\t\tCustomer Telephone No : " << temp->Telephone_No <<endl;
                cout <<"\t\tCustomer Email : " << temp->Email << endl;
                cout <<"\t\tCustomer Nationality : " << temp->Nationality<< endl;
                cout <<"\t\tRented Times : " << temp->Time<< endl;
                cout <<"\n_______________________________________________________________________\n\n";
				temp=temp->next;
		}
	}

}
void Function::exit() //Function to exit
{
	cout<<"\nYou choose to exit.\n"<<endl;
}

//end function exit



