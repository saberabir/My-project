/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palmcategories;

import java.awt.*;
import java.io.FileInputStream;
import java.io.InputStream;
import static java.lang.System.in;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class Palm extends Species {
    String commonName;
    String img;
    String stem;
    String leaf;
    String location;
    String pdate;
    int palmid;

    public String getCommonName() {
        return commonName;
    }

    public String getDate() {
        return pdate;
    }

    public String getImg() {
        return img;
    }

    public String getLocation() {
        return location;
    }

    public String getLeaf() {
        return leaf;
    }

    public String getStem() {
        return stem;
    }
    

    public void setCommonName(String commonName) {
        this.commonName = commonName;
    }

    public void setDate(String date) {
        this.pdate = date;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public void setLeaf(String leaf) {
        this.leaf = leaf;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setStem(String stem) {
        this.stem = stem;
    }

    public int getPalmid() {
        return palmid;
    }

    public void setPalmid(int palmid) {
        this.palmid = palmid;
    }
    
    
      public void insert() throws Exception{
        Connection con = connect_to_DB();
        String sql;
        Statement stmt;
        
        // Get maximun id of genus and increment it by one everytime
        int i=0;
        stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        int maxid=0;
        ResultSet rs ;
        sql = "select max(palm_id) from TBLpalm";
        rs=stmt.executeQuery(sql);
        rs.absolute(1);
        maxid = rs.getInt(1);
        maxid++;
        palmid= maxid;
        //insert into tblspecies
       // System.out.println(id+" " + species_Name+ " "+ species_description);
        PreparedStatement pstmt=con.prepareStatement("insert into tblpalm values(?,?,?,?,?,?,?,?,?)"); 
        InputStream in = new FileInputStream(img);
        pstmt.setInt(1,palmid);
        pstmt.setInt(2,getGenusId());
        pstmt.setInt(3,species_id);
        pstmt.setBlob(4,in);
        pstmt.setString(5,stem);
        pstmt.setString(6,leaf);
        pstmt.setString(7,location);
       // String d = "10-11-2006";
        java.util.Date date = new SimpleDateFormat("yyyy-mm-dd").parse(pdate);
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
           
        pstmt.setDate(8, sqlDate);
        pstmt.setString(9,commonName);
        
        i = pstmt.executeUpdate();
      //   JOptionPane.showMessageDialog(null,"!!! INSERT SUCCESSFULLY ");
        con.close();

    }
      public void update() throws Exception{
        Connection con = connect_to_DB();
        Statement pst;
        pst = con.createStatement();
        java.util.Date date = new SimpleDateFormat("yyyy-mm-dd").parse(pdate);
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        String sql;
       
        if(img == null){
        sql= "Update tblpalm set  genus_id= " + getGenusId() + ", species_id = " + species_id +
               ", stem = '" + stem +"', leaf= '" + leaf + "', location='" + location + "', palm_date = '" + sqlDate +
               "' , commonname = '" + commonName + "'" +
                " where palm_id= " + palmid;
        }
        else{
            // Blob obj = new Blob (in);
            InputStream in = new FileInputStream(img);
            sql= "Update tblpalm set  genus_id= " + getGenusId() + ", species_id = " + species_id +
               ", stem = '" + stem +"', leaf= '" + leaf + "', location='" + location + "', palm_date = '" + sqlDate +
               "' , commonname = '" + commonName + "'" +
                " where palm_id= " + palmid;
        
            PreparedStatement pstmt=con.prepareStatement("update tblpalm set palm_image=? where palm_id = " + palmid ); 
            pstmt.setBlob(1,in);
            pstmt.executeUpdate();
            
        }
        System.out.println(sql);
        pst.executeUpdate(sql);
        //JOptionPane.showMessageDialog(null,"!!! updated SUCCESSFULLY ");
    }  
    public void delete() throws Exception{
        Connection con = connect_to_DB();
        Statement pst;
        pst = con.createStatement();
        String sql= "delete from tblpalm " + " where palm_id= " + palmid ;
        pst.executeUpdate(sql);
        //JOptionPane.showMessageDialog(null,"!!! deleted SUCCESSFULLY ");
    }
}
