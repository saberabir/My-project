/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palmcategories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class Species extends Genus {
    int species_id;
    String species_Name;
    String species_description;
    
    public String getSpecies_Name() {
        return species_Name;
    }

    public void setSpecies_Name(String species_Name) {
        this.species_Name = species_Name;
    }

    public void setSpecies_description(String species_description) {
        this.species_description = species_description;
    }

    public void setSpecies_Description(String Description) {
        this.species_description = Description;
    }

    public int getSpecies_id() {
        return species_id;
    }

    public void setSpecies_id(int species_id) {
        this.species_id = species_id;
    }
    
    
     public void insert() throws Exception{
        Connection con = connect_to_DB();
        String sql;
        Statement stmt;
        
        // Get maximun id of genus and increment it by one everytime
        int i=0;
        stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        int maxid=0;
        ResultSet rs ;
        sql = "select max(species_id) from TBLSpecies";
        rs=stmt.executeQuery(sql);
        rs.absolute(1);
        maxid = rs.getInt(1);
        maxid++;
        species_id = maxid;
               
        //insert into tblspecies
        //System.out.println(id+" " + species_Name+ " "+ species_description);
        PreparedStatement pstmt=con.prepareStatement("insert into tblspecies values(?,?,?,?)");  
        pstmt.setInt(1,getGenusId());
        pstmt.setString(2,species_Name);
        pstmt.setString(3,species_description);
        pstmt.setInt(4,species_id);
        
        i = pstmt.executeUpdate();
        con.close();

    }
     
    public void update() throws Exception{
        Connection con = connect_to_DB();
        Statement pst;
        pst = con.createStatement();
       String sql= "Update tblspecies set species_name = '" + species_Name + "', species_desc = '" + species_description +"', genus_id= " + getGenusId() +
                " where species_id= " + species_id;
    System.out.println(sql);
       pst.executeUpdate(sql);
      
    }
      public void delete() throws Exception{
        Connection con = connect_to_DB();
        Statement pst;
        pst = con.createStatement();
        String sql= "delete from tblspecies " + " where species_id= " + species_id ;
        System.out.println(sql);
        pst.executeUpdate(sql);
        
    }
   
     public ResultSet display_species() throws Exception{
        Connection con = connect_to_DB();
        String sql = "select b.GENUS_ID,a.GENUS_NAME,b.SPECIES_NAME,b.SPECIES_DESC,b.SPECIES_ID from tblgenus as a\n" +
                     "inner join TBLSPECIES as b on a.GENUS_ID=b.GENUS_ID";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //int i =0;
        return rs;
    }
    
    
}
