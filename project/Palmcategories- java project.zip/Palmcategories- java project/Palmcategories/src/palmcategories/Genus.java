/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palmcategories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class Genus {
    private String genusName;
    private String Description;
    private int genusId;

    public String getGenusName() {
        return genusName;
    }

    public void setGenusName(String genusName) {
        this.genusName = genusName;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getDescription() {
        return Description;
    }

    public int getGenusId() {
        return genusId;
    }

    public void setGenusId(int genusId) {
        this.genusId = genusId;
    }
    
    public Connection connect_to_DB() throws Exception{
        Connection con=null;
		try {
                
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
                String url = "jdbc:derby://localhost:1527/PalmCategory";
                con = DriverManager.getConnection(url,"sa","abc");
		    if (con!=null)
		    	System.out.println("");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   return con;  
	}
    public void insert() throws Exception{
        Connection con = connect_to_DB();
        String sql;
        Statement stmt;
        
        // Get maximun id of genus and increment it by one everytime
        int i=0;
        stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        int maxid=0;
        ResultSet rs ;
        sql = "select max(genus_id) from TBLgenus";
        rs=stmt.executeQuery(sql);
        rs.absolute(1);
        maxid = rs.getInt(1);
        maxid++;
        genusId = maxid;
        //insert into tblgenus
        PreparedStatement pstmt=con.prepareStatement("insert into tblgenus values(?,?,?)");  
        pstmt.setInt(1,genusId);
        pstmt.setString(2,genusName);
        pstmt.setString(3,Description);
        i = pstmt.executeUpdate();
        con.close();

    }
    public void update() throws Exception{
        Connection con = connect_to_DB();
        Statement pst;
        pst = con.createStatement();
        String sql= "Update tblgenus set genus_name = '" + genusName + "', genus_desc = '" + Description +"' where genus_id= " + genusId;
        System.out.println(sql);
        pst.executeUpdate(sql);
        JOptionPane.showMessageDialog(null,"!!! updated SUCCESSFULLY ");
    }
      public void delete() throws Exception{
        Connection con = connect_to_DB();
        Statement pst;
        pst = con.createStatement();
        String sql= "delete from tblgenus where genus_id= " + genusId;
        System.out.println(sql);
        pst.executeUpdate(sql);
        JOptionPane.showMessageDialog(null,"!!! deleted SUCCESSFULLY ");
    }
    public ResultSet display() throws Exception{
        Connection con = connect_to_DB();
        DefaultTableModel model = new DefaultTableModel();
        String sql = "select * from tblgenus";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //int i =0;
       return rs;
    }
}
