/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palmcategories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

/**
 *
 * @author Admin
 */
public class Reporting {
    String sql;
    
    public Connection connect_to_DB() throws Exception{
        Connection con=null;
		try {
                
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
                String url = "jdbc:derby://localhost:1527/PalmCategory";
                con = DriverManager.getConnection(url,"sa","abc");
		    if (con!=null)
		    	System.out.println("");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   return con;  
	}
    
    public ResultSet search(String Date) throws Exception{
        Connection con = connect_to_DB();
        sql = "Select * from tblpalm as a " +
                "inner join tblgenus as b on a.genus_id = b.genus_id " +
                "inner join tblspecies as c on b.genus_id= c.genus_id " +
                " where palm_date = '"+ Date + "'";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        return rs;
    }
    public ResultSet search(String location, int i) throws Exception{
        Connection con = connect_to_DB();
        sql = "Select * from tblpalm as a " +
                "inner join tblgenus as b on a.genus_id = b.genus_id " +
                "inner join tblspecies as c on b.genus_id= c.genus_id " +
                " where location = '"+ location + "'";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        return rs;
        
    }
    public ResultSet search(String fromdate,String todate) throws Exception{
        Connection con = connect_to_DB();
        sql = "Select * from tblpalm as a " +
                "inner join tblgenus as b on a.genus_id = b.genus_id " +
                "inner join tblspecies as c on b.genus_id= c.genus_id " +
                " where palm_date between '"+ fromdate + "' and '"+  todate + "'";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        return rs;
    }
    public ResultSet search(String location,String fromdate,String todate) throws Exception{
        Connection con = connect_to_DB();
        sql = "Select * from tblpalm as a " +
                "inner join tblgenus as b on a.genus_id = b.genus_id " +
                "inner join tblspecies as c on b.genus_id= c.genus_id " +
                " where location= '" + location + "' and palm_date between '"+ fromdate + "' and '"+  todate + "'";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        return rs;
    }
}
